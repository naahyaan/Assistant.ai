"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useSupabase } from "@/components/supabase-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Mic, Send, User, Bot } from "lucide-react"
import { cn } from "@/lib/utils"
import { useToast } from "@/components/ui/use-toast"
import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"
import { ThemeToggle } from "@/components/theme-toggle"

type Message = {
  role: "user" | "assistant"
  content: string
}

export default function DashboardPage() {
  const { user } = useSupabase()
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: `Hello${user?.email ? " " + user.email.split("@")[0] : ""}! I'm your AI assistant. How can I help you today?`,
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim()) return

    const userMessage = input.trim()
    setInput("")

    // Add user message to chat
    setMessages((prev) => [...prev, { role: "user", content: userMessage }])

    setIsLoading(true)

    try {
      // Add a placeholder for the assistant's response
      setMessages((prev) => [...prev, { role: "assistant", content: "" }])

      // Format messages for the API
      const apiMessages = messages.map((msg) => ({
        role: msg.role,
        content: msg.content,
      }))

      apiMessages.push({ role: "user", content: userMessage })

      // Stream the response
      const result = streamText({
        model: openai("gpt-4o"),
        messages: apiMessages,
      })

      let fullResponse = ""

      for await (const chunk of result.textStream) {
        fullResponse += chunk

        // Update the last message with the accumulated response
        setMessages((prev) => {
          const newMessages = [...prev]
          newMessages[newMessages.length - 1] = {
            role: "assistant",
            content: fullResponse,
          }
          return newMessages
        })
      }
    } catch (error) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: "Failed to get a response. Please try again.",
        variant: "destructive",
      })

      // Remove the placeholder message
      setMessages((prev) => prev.slice(0, -1))
    } finally {
      setIsLoading(false)
    }
  }

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b p-4">
        <h1 className="text-xl font-bold">Dashboard</h1>
        <ThemeToggle />
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-4 pb-20">
          {messages.map((message, index) => (
            <Card
              key={index}
              className={cn(
                "flex max-w-[80%] flex-col gap-2 rounded-lg p-4",
                message.role === "user" ? "ml-auto bg-primary text-primary-foreground" : "bg-muted",
              )}
            >
              <div className="flex items-center gap-2">
                {message.role === "user" ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                <span className="text-sm font-medium">{message.role === "user" ? "You" : "Assistant"}</span>
              </div>
              <div className="whitespace-pre-wrap">{message.content}</div>
            </Card>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="border-t bg-background p-4">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Button
            type="button"
            size="icon"
            variant="outline"
            onClick={() =>
              toast({
                title: "Voice input",
                description: "Voice input is not available yet.",
              })
            }
          >
            <Mic className="h-5 w-5" />
          </Button>
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1"
            disabled={isLoading}
          />
          <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </div>
  )
}

