"use client"

import { useState, useEffect } from "react"
import { CalendarIcon, Plus, Loader2 } from "lucide-react"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { ThemeToggle } from "@/components/theme-toggle"

// Mock data for calendar events
const mockEvents = [
  {
    id: "1",
    title: "Team Meeting",
    description: "Weekly team sync",
    date: new Date(2023, 6, 15, 10, 0),
    endDate: new Date(2023, 6, 15, 11, 0),
  },
  {
    id: "2",
    title: "Project Review",
    description: "Review project progress",
    date: new Date(2023, 6, 16, 14, 0),
    endDate: new Date(2023, 6, 16, 15, 30),
  },
  {
    id: "3",
    title: "Client Call",
    description: "Discuss new requirements",
    date: new Date(2023, 6, 17, 9, 0),
    endDate: new Date(2023, 6, 17, 10, 0),
  },
]

export default function SchedulesPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [events, setEvents] = useState(mockEvents)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    // Simulate loading events
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleAddEvent = () => {
    toast({
      title: "Feature coming soon",
      description: "Adding events will be available in the next update.",
    })
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b p-4">
        <h1 className="text-xl font-bold">Schedules</h1>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Button onClick={handleAddEvent} size="sm" className="gap-1">
            <Plus className="h-4 w-4" />
            Add Event
          </Button>
        </div>
      </div>
      <div className="grid flex-1 gap-4 p-4 md:grid-cols-[300px_1fr]">
        <div>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start text-left font-normal">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
            </PopoverContent>
          </Popover>
        </div>
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">{date ? format(date, "EEEE, MMMM d, yyyy") : "Select a date"}</h2>
          {loading ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : events.length > 0 ? (
            <div className="space-y-4">
              {events.map((event) => (
                <Card key={event.id}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{event.title}</CardTitle>
                    <CardDescription>
                      {format(event.date, "h:mm a")} - {format(event.endDate, "h:mm a")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{event.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex h-40 items-center justify-center rounded-lg border border-dashed">
              <p className="text-sm text-muted-foreground">No events scheduled for this day</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

